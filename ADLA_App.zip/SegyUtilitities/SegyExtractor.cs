﻿using Microsoft.Analytics.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using Unplugged.Segy;

namespace SegyUtilitities
{
    [SqlUserDefinedExtractor(AtomicFileProcessing = true)]
    public class SegyExtractor : IExtractor
    {
        public override IEnumerable<IRow> Extract(IUnstructuredReader input, IUpdatableRow output)
        {

            var lineNum = @"C([0-9]+)\s";
            var findDelims = @"(\s{3,})";

            var regex = new Regex(findDelims);

            var purgeLineNum = new Regex(lineNum);

            var reader = new SegyReader();

            ISegyFile segyFile = reader.Read(input.BaseStream);

            var header = Regex.Replace(segyFile.Header.Text, lineNum, string.Empty);

            var tokens = Regex.Split(header, findDelims);

            var props = GetHeaders(tokens);

            foreach (var item in props)
            {
                output.Set<string>(item.Item1, item.Item2.Trim());
            }
            
            if(output.Schema.Any(s=>s.Name == "IMAGE"))
            {
                var writer = new Unplugged.Segy.ImageWriter();

                var ioStream = new System.IO.MemoryStream();

                var bmp = writer.GetBitmap(segyFile);

                bmp.Save(ioStream, System.Drawing.Imaging.ImageFormat.Jpeg);

                output.Set<byte[]>("IMAGE", ioStream.ToArray());
            }

            yield return output.AsReadOnly();
        }

        private static IEnumerable<Tuple<string, string>> GetHeaders(IEnumerable<string> lines)
        {
            var cleanLines = from line in lines
                             where !string.IsNullOrWhiteSpace(line.Replace(Environment.NewLine, string.Empty))
                             select line.Trim();

            return (from line in cleanLines
                    where line.IndexOf(':') > 0
                    let vals = line.Split(':')
                    let key = vals != null && vals.Length > 0 ? vals[0] : string.Empty
                    let val = vals != null && vals.Length > 1 ? vals[1] : string.Empty
                    where !string.IsNullOrEmpty(key)
                    select new Tuple<string, string>(key, val)); ;
        }

    }
}