﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Table;
using Unplugged;
using Unplugged.Segy;
using System.Text.RegularExpressions;
using System.IO;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            var lineNum = @"C([0-9]+)\s";
            var findDelims = @"(\s{3,})";

            var regex = new Regex(findDelims);
            var purgeLineNum = new Regex(lineNum);

            var files = System.IO.Directory.GetFiles(System.Environment.CurrentDirectory, "*.segy");

            var totalColumnList = new List<Tuple<string, string>>();

            foreach (var file in files)
            {
                var reader = new SegyReader();

                ISegyFile segyFile = reader.Read(file);

                var header = Regex.Replace(segyFile.Header.Text, lineNum, string.Empty);

                var tokens = Regex.Split(header, findDelims);

                var props = GetHeaders(tokens);

                totalColumnList.AddRange(props);

            }

            foreach (var item in totalColumnList.Select(s=> s.Item1).Distinct())
            {
                Console.WriteLine("[{0}] String,", item);
            }


        }

        private static IEnumerable<Tuple<string,string>> GetHeaders(IEnumerable<string> lines)
        {
            var cleanLines = from line in lines
                             where !string.IsNullOrWhiteSpace(line.Replace(Environment.NewLine, string.Empty))
                             select line.Trim();

            return (from line in cleanLines
                    where line.IndexOf(':') > 0
                    let vals = line.Split(':')
                    let key = vals != null && vals.Length > 0 ? vals[0] : string.Empty
                    let val = vals != null && vals.Length > 1 ? vals[1] : string.Empty
                    where !string.IsNullOrEmpty(key)
                    select new Tuple<string, string>(key, val)); ;
        }

        private static void GenList()
        {
            var account = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=pocshellstorage2;AccountKey=GC+57/3rbTuDgR8/IPY6ofHSFfEvfPSJpAeo8B4noVCPNFwhiM9ndJCUZ6IJPAcaEzWLzD5CWrSST12gudF36w==;EndpointSuffix=core.windows.net");

            var client = account.CreateCloudBlobClient();

            var container = client.GetContainerReference("epc-lake");

            var list = container.ListBlobs(useFlatBlobListing: true, prefix: "");

            if (System.IO.File.Exists("blobList.txt"))
                System.IO.File.Delete("blobList.txt");

            var fs = new System.IO.FileStream("blobList.txt", System.IO.FileMode.OpenOrCreate);

            var writer = new System.IO.StreamWriter(fs);

            foreach (CloudBlockBlob blob in list)
            {
                writer.WriteLine(blob.Name);
            }

            writer.Close();
            fs.Close();
        }
    }
}
