import segypy
import json
import glob

searchpath = "*.segy"
for filename in glob.glob(searchpath):

    # Set verbose level
    segypy.verbose = 0

    # Read Segy File
    [Data, SH, STH] = segypy.readSegy(filename)

    # save headers to json
    with open(filename + '.json', 'w') as sh:
        json.dump(SH, sh)

    segypy.wiggle_save(Data, SH, color='orange')

# save seismic data to png
# plt.pcolormesh(Data)
# plt.savefig(filename + '.png')
